# API-Gateway-Implementation-Ocelot-With-Authentication
In this tutorial, we have explained the architecture of micro-services, and how we can implement the API Gateway for those micro-service, also we have covered how we can move common authentication from all different micro-services to one place that is in web api gateway.
